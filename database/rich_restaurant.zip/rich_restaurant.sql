-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 07, 2021 at 05:03 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rich restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `CLIENT` text NOT NULL,
  `PRODUCT` varchar(300) NOT NULL,
  `ORDER_NO` int(11) NOT NULL,
  `COST` int(11) NOT NULL,
  `STATUS` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`CLIENT`, `PRODUCT`, `ORDER_NO`, `COST`, `STATUS`) VALUES
('Cynthia', 'Milk Shake', 5233, 500, 'Pending');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE `order_products` (
  `ID` int(255) NOT NULL,
  `PRODUCT_ID` varchar(300) NOT NULL,
  `ORDER_ID` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ID` int(255) NOT NULL,
  `FOOD_PRODUCT` text NOT NULL,
  `PRODUCT_TYPE` varchar(300) NOT NULL,
  `PRODUCT_IMAGE` varchar(300) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `PRODUCT_PRICE` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ID`, `FOOD_PRODUCT`, `PRODUCT_TYPE`, `PRODUCT_IMAGE`, `QUANTITY`, `PRODUCT_PRICE`) VALUES
(1, 'Cocktail', 'Beverage', 'login/pics/cocktail1.jpg', 9, '500'),
(2, 'Milk Shake', 'Beverage', 'login/pics/milkshake.jpg', 5, '250'),
(3, 'Fried chicken', 'Lunch', 'login\\pics\\fried_chicken.png', 10, '300'),
(5, 'Sandwich', 'Breakfast', 'login/pics/sandwich.jpg', 10, '150'),
(6, 'Fried fish', 'Lunch', 'login/pics/fried fish.jpg', 10, '1500\r\n'),
(7, 'Lamb chops', 'Dinner', 'login\\pics\\lamb_chops.jpg', 10, '2000'),
(8, 'Biryani', 'Dinner', 'login\\pics\\biryani.jpg', 10, '1000'),
(9, 'Sausage', 'Breakfast', 'login\\pics\\sausage.jpg', 10, '150');

-- --------------------------------------------------------

--
-- Table structure for table `waiter`
--

CREATE TABLE `waiter` (
  `NAME` text NOT NULL,
  `EMPLOYER_NO` int(11) NOT NULL,
  `ZONE` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `waiter`
--

INSERT INTO `waiter` (`NAME`, `EMPLOYER_NO`, `ZONE`) VALUES
('Waiter 1', 101, 'East'),
('Waiter 201', 102, 'EAST'),
('CYNTHIA', 203, 'EAST'),
('Waiter 1', 101, 'EAST'),
('Waiter 1', 101, 'EAST');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`ORDER_NO`);

--
-- Indexes for table `order_products`
--
ALTER TABLE `order_products`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `order_products`
--
ALTER TABLE `order_products`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
